import { ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";
import { branches, navigation, site } from "../lib/coreData";
import { buildWhatsApp, cleanTel, getPrimaryBranch, getPrimaryPhone } from "../lib/contact";

export default function Footer() {
  const primaryBranch = getPrimaryBranch(branches.items);
  const primaryPhone = getPrimaryPhone(primaryBranch);
  const careLinks = navigation.footer[2]?.items ?? [];

  function openCookiePreferences() {
    window.dispatchEvent(new Event("aakash:open-cookie-preferences"));
  }

  function scrollToTop() {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  return (
    <footer className="ft" id="site-footer">
      <div className="e-shell">
        <div className="ft__top">
          <div>
            <img className="ft__wordmark" src={site.brand.logo} alt={site.brand.logoAlt} />
            <p>{site.footer.summary}</p>
          </div>
          <div className="ft__cta">
            <h2>Need an eye check-up or a second opinion?</h2>
            <div className="ft__cta-actions">
              <Link className="e-btn e-btn--light" to="/appointment">
                Book an appointment
                <ArrowRight size={17} aria-hidden="true" />
              </Link>
              <a
                className="e-link e-link--light"
                href={buildWhatsApp(primaryBranch)}
                target="_blank"
                rel="noreferrer"
              >
                WhatsApp us
                <ArrowRight size={15} aria-hidden="true" />
              </a>
            </div>
          </div>
        </div>

        <div className="ft__cols">
          <section className="ft__col" aria-labelledby="ft-hospitals">
            <h3 id="ft-hospitals">Our hospitals</h3>
            <ul className="ft__list">
              {branches.items.map((branch) => (
                <li key={branch.slug}>
                  <Link to={`/branches?branch=${branch.slug}`}>
                    {branch.name}
                    <em>{branch.isHeadquarters ? "Head office" : "Branch"}</em>
                  </Link>
                </li>
              ))}
            </ul>
          </section>

          <section className="ft__col" aria-labelledby="ft-care">
            <h3 id="ft-care">Treatments</h3>
            <ul className="ft__list">
              {careLinks.map((item) => (
                <li key={item.href}>
                  <Link to={item.href}>{item.label}</Link>
                </li>
              ))}
              <li>
                <Link to="/services">All treatments</Link>
              </li>
            </ul>
          </section>

          <section className="ft__col" aria-labelledby="ft-hospital">
            <h3 id="ft-hospital">Hospital</h3>
            <ul className="ft__list">
              <li>
                <Link to="/about">About</Link>
              </li>
              <li>
                <Link to="/doctors">Doctors</Link>
              </li>
              <li>
                <Link to="/gallery">Gallery</Link>
              </li>
              <li>
                <Link to="/branches">Branches</Link>
              </li>
              <li>
                <Link to="/contact">Contact</Link>
              </li>
            </ul>
          </section>

          <section className="ft__col" aria-labelledby="ft-contact">
            <h3 id="ft-contact">Contact</h3>
            <ul className="ft__contact">
              <li>
                <span>{primaryBranch.name} OPD</span>
                <a href={`tel:${cleanTel(primaryPhone)}`}>{primaryPhone}</a>
              </li>
              <li>
                <span>Email</span>
                <a href={`mailto:${primaryBranch.email}`}>{primaryBranch.email}</a>
              </li>
              <li>
                <span>{site.businessHours[0]?.label}</span>
                <strong>{site.businessHours[0]?.value}</strong>
              </li>
            </ul>
            {site.socialLinks?.length ? (
              <div className="ft__social">
                {site.socialLinks.map((link) => (
                  <a key={link.href} href={link.href} target="_blank" rel="noreferrer">
                    {link.label}
                  </a>
                ))}
              </div>
            ) : null}
          </section>
        </div>

        <div className="ft__bottom">
          <p>
            &copy; {new Date().getFullYear()} {site.footer.copyright}
          </p>
          <div className="ft__bottom-links">
            <button type="button" onClick={openCookiePreferences}>
              Privacy &amp; cookie preferences
            </button>
            <button type="button" onClick={scrollToTop}>
              Back to top
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}
