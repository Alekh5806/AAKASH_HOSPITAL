import { useEffect, useRef, useState } from "react";
import { CalendarDays, ChevronDown, Menu, Phone, X } from "lucide-react";
import { Link, NavLink, useLocation } from "react-router-dom";
import { branches, navigation, site } from "../lib/coreData";
import ButtonLink from "./ButtonLink";

function buildBranchHref(slug) {
  return `/branches?branch=${slug}`;
}

function HospitalNavItem({ isMobile = false, location, hospitalsOpen, onNavigate, onToggle }) {
  const selectedBranchSlug = new URLSearchParams(location.search).get("branch");
  const isHospitalSectionActive =
    location.pathname === "/branches" || location.pathname.startsWith("/our-hospitals/");
  const hospitalLinks = [
    {
      label: "All Hospitals",
      href: "/branches",
      description: "View every branch",
      isActive: isHospitalSectionActive && !selectedBranchSlug,
    },
    ...branches.items.map((branch) => ({
      label: branch.name,
      href: buildBranchHref(branch.slug),
      description: branch.isHeadquarters ? "Head Office" : "Branch",
      isActive: selectedBranchSlug === branch.slug,
    })),
  ];

  if (isMobile) {
    return (
      <div className="mobile-nav-group">
        <button
          className="nav-link mobile-nav-group__toggle"
          type="button"
          aria-expanded={hospitalsOpen}
          aria-controls="mobile-hospitals-menu"
          onClick={onToggle}
        >
          <span>Our Hospitals</span>
          <ChevronDown size={16} aria-hidden="true" />
        </button>
        {hospitalsOpen ? (
          <div className="mobile-nav-group__menu" id="mobile-hospitals-menu">
            {hospitalLinks.map((item) => (
              <Link
                key={item.href}
                to={item.href}
                className={`mobile-nav-group__item ${item.isActive ? "mobile-nav-group__item--active" : ""}`}
                onClick={onNavigate}
              >
                <strong>{item.label}</strong>
                <span>{item.description}</span>
              </Link>
            ))}
          </div>
        ) : null}
      </div>
    );
  }

  return (
    <div className="nav-dropdown">
      <Link
        to="/branches"
        className={`nav-link nav-dropdown__trigger ${isHospitalSectionActive ? "nav-link--active" : ""}`}
        aria-haspopup="menu"
      >
        <span>Our Hospitals</span>
        <ChevronDown size={16} aria-hidden="true" />
      </Link>
      <div className="nav-dropdown__menu" role="menu" aria-label="Our Hospitals">
        {hospitalLinks.map((item) => (
          <Link
            key={item.href}
            to={item.href}
            role="menuitem"
            className={`nav-dropdown__item ${item.isActive ? "nav-dropdown__item--active" : ""}`}
            onClick={onNavigate}
          >
            <strong>{item.label}</strong>
            <span>{item.description}</span>
          </Link>
        ))}
      </div>
    </div>
  );
}

function NavItems({ hospitalsOpen = false, isMobile = false, location, onNavigate, onToggle }) {
  return navigation.header.map((item) => (
    item.href === "/branches" ? (
      <HospitalNavItem
        key={item.href}
        isMobile={isMobile}
        location={location}
        hospitalsOpen={hospitalsOpen}
        onNavigate={onNavigate}
        onToggle={onToggle}
      />
    ) : (
      <NavLink
        key={item.href}
        to={item.href}
        className={({ isActive }) => `nav-link ${isActive ? "nav-link--active" : ""}`}
        onClick={onNavigate}
      >
        {item.label}
      </NavLink>
    )
  ));
}

export default function Header() {
  const [open, setOpen] = useState(false);
  const [hospitalsOpen, setHospitalsOpen] = useState(false);
  const panelRef = useRef(null);
  const location = useLocation();
  const locationKey = `${location.pathname}${location.search}`;
  const previousPathRef = useRef(locationKey);

  useEffect(() => {
    if (previousPathRef.current === locationKey) return undefined;
    previousPathRef.current = locationKey;
    if (!open && !hospitalsOpen) return undefined;
    const frame = requestAnimationFrame(() => {
      setOpen(false);
      setHospitalsOpen(false);
    });
    return () => cancelAnimationFrame(frame);
  }, [hospitalsOpen, locationKey, open]);

  useEffect(() => {
    if (!open) return undefined;

    const panel = panelRef.current;
    const selector = 'a[href], button:not([disabled]), [tabindex]:not([tabindex="-1"])';
    const focusable = Array.from(panel?.querySelectorAll(selector) ?? []);
    const previousOverflow = document.body.style.overflow;

    document.body.style.overflow = "hidden";
    focusable[0]?.focus();

    function onKeyDown(event) {
      if (event.key === "Escape") {
        setOpen(false);
      }

      if (event.key !== "Tab" || focusable.length === 0) return;

      const first = focusable[0];
      const last = focusable[focusable.length - 1];

      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    }

    document.addEventListener("keydown", onKeyDown);
    return () => {
      document.body.style.overflow = previousOverflow;
      document.removeEventListener("keydown", onKeyDown);
    };
  }, [open]);

  return (
    <header className="site-header">
      <div className="site-header__top">
        <div className="container site-header__top-inner">
          <a href={site.globalCtas.secondary.href}>
            <Phone size={15} aria-hidden="true" />
            <span>{site.globalCtas.secondary.label}</span>
          </a>
          <span>{site.brand.tagline}</span>
        </div>
      </div>
      <div className="container site-header__inner">
        <Link className="brand-mark" to="/" aria-label={`${site.brand.name} home`}>
          <img src={site.brand.logo} alt={site.brand.logoAlt} />
        </Link>
        <nav className="site-nav" aria-label="Primary navigation">
          <NavItems location={location} />
        </nav>
        <div className="site-header__actions">
          <ButtonLink to="/appointment" icon={CalendarDays}>
            Book
          </ButtonLink>
          <button
            className="icon-button menu-button"
            type="button"
            aria-label="Open menu"
            aria-expanded={open}
            aria-controls="mobile-menu"
            onClick={() => {
              setHospitalsOpen(false);
              setOpen(true);
            }}
          >
            <Menu size={22} aria-hidden="true" />
          </button>
        </div>
      </div>

      {open ? (
        <div className="mobile-menu" role="dialog" aria-modal="true" id="mobile-menu">
          <div ref={panelRef} className="mobile-menu__panel">
            <div className="mobile-menu__head">
              <img src={site.brand.logo} alt={site.brand.logoAlt} />
              <button
                className="icon-button"
                type="button"
                aria-label="Close menu"
                onClick={() => {
                  setHospitalsOpen(false);
                  setOpen(false);
                }}
              >
                <X size={22} aria-hidden="true" />
              </button>
            </div>
            <nav className="mobile-menu__nav" aria-label="Mobile navigation">
              <NavItems
                hospitalsOpen={hospitalsOpen}
                isMobile
                location={location}
                onNavigate={() => {
                  setHospitalsOpen(false);
                  setOpen(false);
                }}
                onToggle={() => setHospitalsOpen((current) => !current)}
              />
            </nav>
            <ButtonLink to="/appointment" icon={CalendarDays} onClick={() => setOpen(false)}>
              Book Appointment
            </ButtonLink>
          </div>
        </div>
      ) : null}
    </header>
  );
}
