import SEO from "../components/SEO";
import { BranchJsonLd, MedicalClinicJsonLd } from "../components/JsonLd";
import { branches } from "../lib/coreData";
import { doctors } from "../lib/doctorsData";
import { home } from "../lib/homeData";
import { getServicesByIds, services } from "../lib/servicesData";
import { testimonials } from "../lib/testimonialsData";
import AppointmentBand from "../sections/AppointmentBand";
import BranchLocator from "../sections/BranchLocator";
import FactRow from "../sections/FactRow";
import FeatureSpread from "../sections/FeatureSpread";
import Hero from "../sections/Hero";
import PatientStories from "../sections/PatientStories";
import SpecialistsRail from "../sections/SpecialistsRail";
import TreatmentIndex from "../sections/TreatmentIndex";
import WhyChooseUs from "../sections/WhyChooseUs";

export default function HomePage() {
  const featured = getServicesByIds(home.featuredServiceIds);

  return (
    <>
      <SEO meta={home.seo} />
      <MedicalClinicJsonLd services={services.items} />
      <BranchJsonLd />
      <Hero hero={home.hero} />
      <FactRow facts={home.facts} />
      <TreatmentIndex quickTreatments={home.quickTreatments} />
      <FeatureSpread service={featured[0]} />
      <WhyChooseUs trust={home.trust} />
      <SpecialistsRail doctors={doctors.items.slice(0, 4)} />
      <BranchLocator branches={branches.items} />
      <PatientStories testimonials={testimonials.items} />
      <AppointmentBand cta={home.cta} />
    </>
  );
}
