import { ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";
import { branches } from "../lib/coreData";
import { buildWhatsApp, cleanTel, getPrimaryBranch, getPrimaryPhone } from "../lib/contact";

export default function AppointmentBand({ cta }) {
  const primaryBranch = getPrimaryBranch(branches.items);
  const primaryPhone = getPrimaryPhone(primaryBranch);

  return (
    <section className="e-close" aria-labelledby="e-close-title">
      <div className="e-shell e-close__inner">
        <div>
          <h2 id="e-close-title">{cta.title}</h2>
          <p>{cta.description}</p>
        </div>
        <div className="e-close__side">
          <div className="e-close__actions">
            <Link className="e-btn e-btn--light" to={cta.primary.href}>
              {cta.primary.label}
              <ArrowRight size={17} aria-hidden="true" />
            </Link>
            <a
              className="e-btn e-btn--outline-light"
              href={buildWhatsApp(primaryBranch)}
              target="_blank"
              rel="noreferrer"
            >
              WhatsApp
            </a>
          </div>
          <div className="e-close__phone">
            <span>{primaryBranch.name} OPD</span>
            <a href={`tel:${cleanTel(primaryPhone)}`}>{primaryPhone}</a>
          </div>
        </div>
      </div>
    </section>
  );
}
