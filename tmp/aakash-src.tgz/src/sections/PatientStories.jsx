import { motion, useReducedMotion } from "framer-motion";
import { revealVariants, staggerContainer } from "../lib/motion";

export default function PatientStories({ testimonials }) {
  const shouldReduceMotion = useReducedMotion();

  return (
    <section className="e-sec e-sec--paper e-voices" aria-labelledby="e-voices-title">
      <div className="e-shell">
        <div className="e-head e-head--wide">
          <span className="e-label">06 &mdash; Patient feedback</span>
          <div className="e-head__body">
            <h2 className="e-h2" id="e-voices-title">
              What patients tell us after a visit
            </h2>
            <p className="e-lede">
              Recurring themes drawn from public reviews across our branches. These are summarised,
              not quoted, so no words are put in a patient&apos;s mouth.
            </p>
          </div>
        </div>

        <motion.div
          className="e-voices__grid"
          variants={staggerContainer(shouldReduceMotion)}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.12 }}
        >
          {testimonials.map((item) => (
            <motion.article
              className="e-voice"
              key={item.theme}
              variants={revealVariants(shouldReduceMotion)}
            >
              <blockquote>{item.quote}</blockquote>
              <footer>
                <span>{item.theme}</span>
                <span>{item.location}</span>
              </footer>
            </motion.article>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
