import { ArrowRight, Compass } from "lucide-react";
import { Link } from "react-router-dom";
import { getIcon } from "../lib/icons";
import { getServicesByIds } from "../lib/servicesData";

export default function QuickTreatments({ quickTreatments }) {
  const items = getServicesByIds(quickTreatments.serviceIds);

  return (
    <section className="lp-section lp-section--tight lp-care" aria-labelledby="lp-care-title">
      <div className="lp-shell">
        <div className="lp-head-row">
          <div className="lp-head">
            <span className="lp-eyebrow">
              <Compass size={13} aria-hidden="true" />
              {quickTreatments.eyebrow}
            </span>
            <h2 className="lp-title" id="lp-care-title">
              What brings you here <em>today?</em>
            </h2>
          </div>
          <Link className="lp-more" to="/services">
            All treatments
            <ArrowRight size={16} aria-hidden="true" />
          </Link>
        </div>

        <div className="lp-care__grid">
          {items.map((service) => {
            const Icon = getIcon(service.icon);

            return (
              <Link className="lp-care__item" key={service.id} to={`/services/${service.slug}`}>
                <span className="lp-care__icon">
                  <Icon size={22} aria-hidden="true" />
                </span>
                <span className="lp-care__text">
                  <strong>{service.quickLabel ?? service.title}</strong>
                  <span>View care pathway</span>
                </span>
                <ArrowRight className="lp-care__arrow" size={17} aria-hidden="true" />
              </Link>
            );
          })}
        </div>
      </div>
    </section>
  );
}
