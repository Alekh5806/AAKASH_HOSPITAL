import { motion, useReducedMotion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";
import { revealVariants, staggerContainer } from "../lib/motion";

export default function SpecialistsRail({ doctors }) {
  const shouldReduceMotion = useReducedMotion();

  return (
    <section className="e-sec e-people" aria-labelledby="e-people-title">
      <div className="e-shell">
        <div className="e-head">
          <span className="e-label">04 &mdash; Specialists</span>
          <div className="e-head__body e-head__row">
            <h2 className="e-h2" id="e-people-title">
              The surgeons who will see you
            </h2>
            <Link className="e-link" to="/doctors">
              Full team
              <ArrowRight size={15} aria-hidden="true" />
            </Link>
          </div>
        </div>

        <motion.div
          className="e-people__grid"
          variants={staggerContainer(shouldReduceMotion)}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.12 }}
        >
          {doctors.map((doctor) => (
            <motion.article
              className="e-person"
              key={doctor.name}
              variants={revealVariants(shouldReduceMotion)}
            >
              <div className="e-person__media">
                <img src={doctor.photo} alt={doctor.photoAlt} loading="lazy" decoding="async" />
              </div>
              <div className="e-person__body">
                <h3>{doctor.name}</h3>
                <p className="e-person__qual">{doctor.qualifications}</p>
                <p className="e-person__spec">
                  {doctor.specialty} &middot; {doctor.branches.join(", ")}
                </p>
              </div>
            </motion.article>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
