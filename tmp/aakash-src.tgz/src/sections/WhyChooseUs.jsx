import { motion, useReducedMotion } from "framer-motion";
import { revealVariants, staggerContainer } from "../lib/motion";

export default function WhyChooseUs({ trust }) {
  const shouldReduceMotion = useReducedMotion();

  return (
    <section className="e-sec e-sec--dark e-why" aria-labelledby="e-why-title">
      <div className="e-shell">
        <div className="e-head e-head--wide">
          <span className="e-label">03 &mdash; Why Aakash</span>
          <div className="e-head__body">
            <h2 className="e-h2" id="e-why-title">
              Three decades of ophthalmology, one consistent promise
            </h2>
            <p className="e-lede">
              Honest guidance before a decision is made, modern technology behind every procedure,
              and a case file that stays open for life.
            </p>
          </div>
        </div>

        <motion.ul
          className="e-why__grid"
          variants={staggerContainer(shouldReduceMotion)}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.15 }}
        >
          {trust.items.map((item, index) => (
            <motion.li
              className="e-why__item"
              key={item.title}
              variants={revealVariants(shouldReduceMotion)}
            >
              <span>{String(index + 1).padStart(2, "0")}</span>
              <strong>{item.title}</strong>
              <p>{item.description}</p>
            </motion.li>
          ))}
        </motion.ul>
      </div>
    </section>
  );
}
