export default function FactRow({ facts }) {
  return (
    <section className="e-facts" aria-label="Aakash Eye Hospital in numbers">
      <div className="e-shell">
        <div className="e-facts__grid">
          {facts.map((fact) => (
            <div className="e-facts__item" key={fact.label}>
              <strong className="e-num">{fact.value}</strong>
              <span>{fact.label}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
