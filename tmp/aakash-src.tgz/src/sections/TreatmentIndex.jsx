import { ArrowRight, ArrowUpRight } from "lucide-react";
import { Link } from "react-router-dom";
import { getServicesByIds } from "../lib/servicesData";

export default function TreatmentIndex({ quickTreatments }) {
  const items = getServicesByIds(quickTreatments.serviceIds);

  return (
    <section className="e-sec e-treatments" aria-labelledby="e-treatments-title">
      <div className="e-shell">
        <div className="e-head">
          <span className="e-label">01 &mdash; Treatments</span>
          <div className="e-head__body e-head__row">
            <h2 className="e-h2" id="e-treatments-title">
              Care for every stage of sight
            </h2>
            <Link className="e-link" to="/services">
              All treatments
              <ArrowRight size={15} aria-hidden="true" />
            </Link>
          </div>
        </div>

        <div className="e-index">
          {items.map((service, index) => (
            <Link className="e-index__row" key={service.id} to={`/services/${service.slug}`}>
              <span className="e-index__num">{String(index + 1).padStart(2, "0")}</span>
              <h3 className="e-index__name">{service.quickLabel ?? service.title}</h3>
              <p className="e-index__desc">{service.shortDescription}</p>
              <ArrowUpRight className="e-index__arrow" size={20} aria-hidden="true" />
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
