import { useMemo, useState } from "react";
import { ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";
import LazyMapFrame from "../components/LazyMapFrame";
import { buildMapLink, buildWhatsApp, cleanTel, getPrimaryBranch } from "../lib/contact";

export default function BranchLocator({ branches }) {
  const defaultSlug = getPrimaryBranch(branches)?.slug ?? branches[0]?.slug;
  const [selectedSlug, setSelectedSlug] = useState(defaultSlug);
  const branch = useMemo(
    () => branches.find((item) => item.slug === selectedSlug) ?? branches[0],
    [branches, selectedSlug],
  );

  if (!branch) return null;

  return (
    <section className="e-sec e-locator" aria-labelledby="e-locator-title">
      <div className="e-shell">
        <div className="e-head">
          <span className="e-label">05 &mdash; Our hospitals</span>
          <div className="e-head__body e-head__row">
            <h2 className="e-h2" id="e-locator-title">
              Six hospitals across Gujarat
            </h2>
            <Link className="e-link" to="/branches">
              All locations
              <ArrowRight size={15} aria-hidden="true" />
            </Link>
          </div>
        </div>

        <div className="e-loc">
          <div className="e-loc__list" role="tablist" aria-label="Select a hospital">
            {branches.map((item) => (
              <button
                className="e-loc__item"
                key={item.slug}
                type="button"
                role="tab"
                aria-selected={item.slug === branch.slug}
                onClick={() => setSelectedSlug(item.slug)}
              >
                <strong>{item.name}</strong>
                <em>{item.isHeadquarters ? "Head office" : "Branch"}</em>
              </button>
            ))}
          </div>

          <div className="e-loc__panel">
            <div className="e-loc__map">
              <LazyMapFrame
                title={`Map to Aakash Eye Hospital ${branch.name}`}
                src={branch.mapEmbed}
              />
            </div>

            <p className="e-loc__address">{branch.address}</p>

            <div className="e-loc__phones">
              {branch.phoneGroups.map((group) => (
                <div key={group.label}>
                  <strong>{group.label}</strong>
                  {group.numbers.map((number) => (
                    <a href={`tel:${cleanTel(number)}`} key={number}>
                      {number}
                    </a>
                  ))}
                </div>
              ))}
              <div>
                <strong>Email</strong>
                <a href={`mailto:${branch.email}`}>{branch.email}</a>
              </div>
            </div>

            <div className="e-loc__actions">
              <Link className="e-btn" to={`/appointment?branch=${branch.slug}`}>
                Book at {branch.name}
                <ArrowRight size={17} aria-hidden="true" />
              </Link>
              <a className="e-link" href={buildWhatsApp(branch)} target="_blank" rel="noreferrer">
                WhatsApp this branch
                <ArrowRight size={15} aria-hidden="true" />
              </a>
              <a className="e-link" href={buildMapLink(branch)} target="_blank" rel="noreferrer">
                Directions
                <ArrowRight size={15} aria-hidden="true" />
              </a>
            </div>

            <p className="e-loc__hours">{branch.hoursLabel}</p>
          </div>
        </div>
      </div>
    </section>
  );
}
