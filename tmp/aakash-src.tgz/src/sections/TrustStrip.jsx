import { Award, Eye, MapPinned, Microscope } from "lucide-react";

const ICONS = [Award, MapPinned, Eye, Microscope];

export default function TrustStrip({ stats }) {
  return (
    <section className="lp-trust" aria-label="Hospital credentials">
      <div className="lp-shell">
        <div className="lp-trust__inner">
          {stats.slice(0, 4).map((stat, index) => {
            const Icon = ICONS[index] ?? Award;
            const value =
              stat.value >= 100000
                ? "1,00,000+"
                : `${stat.value.toLocaleString("en-IN")}${stat.suffix ?? ""}`;

            return (
              <div className="lp-trust__item" key={stat.label}>
                <span className="lp-trust__icon">
                  <Icon size={22} aria-hidden="true" />
                </span>
                <div>
                  <strong>{value}</strong>
                  <span>{stat.label}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
