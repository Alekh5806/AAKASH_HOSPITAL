import { useEffect, useState } from "react";
import { motion, useReducedMotion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";
import { branches } from "../lib/coreData";
import { cleanTel, getPrimaryBranch, getPrimaryPhone } from "../lib/contact";

const SLIDE_MS = 6500;

export default function Hero({ hero }) {
  const [active, setActive] = useState(0);
  const shouldReduceMotion = useReducedMotion();
  const primaryBranch = getPrimaryBranch(branches.items);
  const primaryPhone = getPrimaryPhone(primaryBranch);

  useEffect(() => {
    if (shouldReduceMotion || hero.slides.length < 2) return undefined;
    const timer = window.setInterval(() => {
      setActive((index) => (index + 1) % hero.slides.length);
    }, SLIDE_MS);

    return () => window.clearInterval(timer);
  }, [hero.slides.length, shouldReduceMotion]);

  return (
    <section className="e-hero" aria-label="Aakash Eye Hospital">
      <div className="e-hero__stage" aria-hidden="true">
        {hero.slides.map((slide, index) => (
          <motion.img
            key={slide.image}
            src={slide.image}
            alt=""
            loading={index === 0 ? "eager" : "lazy"}
            decoding="async"
            fetchPriority={index === 0 ? "high" : "auto"}
            initial={false}
            animate={{
              opacity: active === index ? 1 : 0,
              scale: shouldReduceMotion ? 1 : active === index ? 1.06 : 1,
            }}
            transition={{
              opacity: { duration: shouldReduceMotion ? 0 : 1.2, ease: "easeInOut" },
              scale: { duration: shouldReduceMotion ? 0 : SLIDE_MS / 1000 + 1.4, ease: "linear" },
            }}
          />
        ))}
      </div>
      <div className="e-hero__scrim" aria-hidden="true" />

      <div className="e-shell e-hero__inner">
        <motion.div
          initial={shouldReduceMotion ? { opacity: 1 } : { opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: shouldReduceMotion ? 0 : 0.8, ease: [0.32, 0.72, 0, 1] }}
        >
          <p className="e-hero__kicker">
            Aakash Eye Hospital &middot; Since 1993
          </p>
          <h1>
            {hero.title}
            <br />
            {hero.titleAccent}
          </h1>
          <p className="e-hero__lede">{hero.subtitle}</p>
          <div className="e-hero__actions">
            <Link className="e-btn e-btn--light" to="/appointment">
              Book an appointment
              <ArrowRight size={17} aria-hidden="true" />
            </Link>
            <Link className="e-link e-link--light" to="/branches">
              Find your hospital
              <ArrowRight size={15} aria-hidden="true" />
            </Link>
            <a className="e-link e-link--light" href={`tel:${cleanTel(primaryPhone)}`}>
              Call {primaryBranch.name} OPD
              <ArrowRight size={15} aria-hidden="true" />
            </a>
          </div>
        </motion.div>
      </div>

      <div className="e-hero__foot">
        <div className="e-shell e-hero__foot-inner">
          <span className="e-hero__count">
            {String(active + 1).padStart(2, "0")} / {String(hero.slides.length).padStart(2, "0")}
          </span>
          <span className="e-hero__caption">{hero.slides[active].title}</span>
          <span className="e-hero__ticks">
            {hero.slides.map((slide, index) => (
              <button
                key={slide.title}
                type="button"
                aria-label={`Show ${slide.title}`}
                aria-pressed={active === index}
                onClick={() => setActive(index)}
              />
            ))}
          </span>
        </div>
      </div>
    </section>
  );
}
