import { motion, useReducedMotion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";

export default function FeatureSpread({ service }) {
  const shouldReduceMotion = useReducedMotion();

  if (!service) return null;

  return (
    <section className="e-sec e-sec--paper" aria-labelledby="e-feature-title">
      <div className="e-shell">
        <div className="e-head">
          <span className="e-label">02 &mdash; Signature care</span>
          <div className="e-head__body">
            <h2 className="e-h2" id="e-feature-title">
              Bladeless precision, planned around your eye
            </h2>
          </div>
        </div>

        <motion.div
          className="e-feature"
          initial={shouldReduceMotion ? { opacity: 1 } : { opacity: 0, y: 18 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: shouldReduceMotion ? 0 : 0.7, ease: [0.32, 0.72, 0, 1] }}
        >
          <div className="e-feature__media">
            <img src={service.image} alt={service.imageAlt} loading="lazy" decoding="async" />
          </div>
          <div className="e-feature__body">
            <h3 className="e-h3">{service.title}</h3>
            <p className="e-lede">{service.shortDescription}</p>
            {service.featureBullets?.length ? (
              <ul className="e-feature__list">
                {service.featureBullets.slice(0, 4).map((bullet) => (
                  <li key={bullet}>{bullet}</li>
                ))}
              </ul>
            ) : null}
            <div className="e-feature__actions">
              <Link className="e-btn" to={`/services/${service.slug}`}>
                Read about this treatment
                <ArrowRight size={17} aria-hidden="true" />
              </Link>
              <Link className="e-link" to="/appointment">
                Book a consultation
                <ArrowRight size={15} aria-hidden="true" />
              </Link>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
