import { motion, useReducedMotion } from "framer-motion";
import { ArrowRight, ArrowUpRight, CalendarDays, Check, Sparkles } from "lucide-react";
import { Link } from "react-router-dom";
import { getIcon } from "../lib/icons";
import { revealVariants, staggerContainer } from "../lib/motion";

export default function SignatureServices({ services }) {
  const shouldReduceMotion = useReducedMotion();
  const [lead, ...rest] = services;

  if (!lead) return null;

  return (
    <section className="lp-section lp-services" aria-labelledby="lp-services-title">
      <div className="lp-shell">
        <div className="lp-head-row">
          <div className="lp-head">
            <span className="lp-eyebrow">
              <Sparkles size={13} aria-hidden="true" />
              Signature care
            </span>
            <h2 className="lp-title" id="lp-services-title">
              Advanced procedures, <em>gently delivered.</em>
            </h2>
            <p className="lp-lede">
              Technology-led surgical and diagnostic pathways, explained in plain language before
              you decide anything.
            </p>
          </div>
          <Link className="lp-more" to="/services">
            All services
            <ArrowRight size={16} aria-hidden="true" />
          </Link>
        </div>

        <motion.article
          className="lp-feature"
          initial={shouldReduceMotion ? { opacity: 1 } : { opacity: 0, y: 22 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.18 }}
          transition={{ duration: shouldReduceMotion ? 0 : 0.7, ease: [0.22, 1, 0.36, 1] }}
        >
          <div className="lp-feature__media">
            <img src={lead.image} alt={lead.imageAlt} loading="eager" decoding="async" />
            <span className="lp-feature__tag">
              <Sparkles size={12} aria-hidden="true" />
              Most requested
            </span>
          </div>
          <div className="lp-feature__body">
            <h3>{lead.title}</h3>
            <p>{lead.shortDescription}</p>
            {lead.featureBullets?.length ? (
              <ul className="lp-feature__bullets">
                {lead.featureBullets.slice(0, 3).map((bullet) => (
                  <li key={bullet}>
                    <Check size={16} aria-hidden="true" />
                    {bullet}
                  </li>
                ))}
              </ul>
            ) : null}
            <div className="lp-feature__actions">
              <Link className="lp-btn lp-btn--primary" to={`/services/${lead.slug}`}>
                <ArrowUpRight size={17} aria-hidden="true" />
                Explore treatment
              </Link>
              <Link className="lp-btn lp-btn--outline" to="/appointment">
                <CalendarDays size={17} aria-hidden="true" />
                Book a consult
              </Link>
            </div>
          </div>
        </motion.article>

        <motion.div
          className="lp-services__grid"
          variants={staggerContainer(shouldReduceMotion)}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.12 }}
        >
          {rest.map((service) => {
            const Icon = getIcon(service.icon);

            return (
              <motion.article
                className="lp-scard"
                key={service.id}
                variants={revealVariants(shouldReduceMotion)}
              >
                <div className="lp-scard__media">
                  <img
                    src={service.image}
                    alt={service.imageAlt}
                    loading="lazy"
                    decoding="async"
                  />
                </div>
                <div className="lp-scard__body">
                  <span className="lp-scard__icon">
                    <Icon size={21} aria-hidden="true" />
                  </span>
                  <h3>{service.title}</h3>
                  <p>{service.shortDescription}</p>
                  <span className="lp-scard__link">
                    Explore treatment
                    <ArrowUpRight size={16} aria-hidden="true" />
                  </span>
                </div>
                <Link
                  className="lp-scard__cover"
                  to={`/services/${service.slug}`}
                  aria-label={`Read about ${service.title}`}
                />
              </motion.article>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
}
