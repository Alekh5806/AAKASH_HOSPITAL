# Aakash Eye Hospital Project Guide

This project is a production-ready, mobile-first website for Aakash Eye Hospital. The goal is to present a clear, premium, trustworthy, and easy-to-use digital experience for a multi-branch eye hospital. Most visitors are expected to use mobile devices, so every implementation decision must protect small-screen usability first.

## Product Direction

- Build a direct, simple, patient-friendly hospital website, not a complex web app.
- Prioritize fast navigation to services, doctors, hospitals, contact numbers, WhatsApp, maps, and appointment booking.
- Keep pages focused and easy to scan. Avoid long marketing sections, unnecessary animations, and complicated interactions.
- Design for a world-class multi-branch eye hospital: professional, clinical, calm, trustworthy, and polished.
- Mobile UI/UX is the primary experience. Desktop must still look premium, but mobile should never feel like an afterthought.
- Content should be clear for patients and families, including older users who may need larger touch targets, readable text, and obvious actions.

## Tech Stack

Runtime:

- React 19
- React DOM 19
- React Router DOM 7
- Vite 8
- Framer Motion for controlled animation
- Lucide React for icons
- React Hook Form for forms
- Zod and `@hookform/resolvers` for validation

Development:

- ESLint 9 with React, hooks, and refresh plugins
- Prettier 3
- Cloudflare Pages compatible static deployment

Important commands:

```bash
npm install
npm run dev
npm run lint
npm run build
npm run preview
```

Deployment target:

- Build command: `npm run build`
- Output directory: `dist`
- Public static assets served from `public`
- Required production environment variable: `VITE_WEB3FORMS_ACCESS_KEY`

## Current File Structure

```text
.
|-- claude.md
|-- eslint.config.js
|-- index.html
|-- package.json
|-- README.md
|-- vite.config.js
|-- public
|   |-- robots.txt
|   |-- sitemap.xml
|   `-- assets
|       `-- media
|           |-- doctors
|           |-- gallery
|           |-- heroes
|           |-- page-headers
|           `-- stock
`-- src
    |-- main.jsx
    |-- router.jsx
    |-- assets
    |   `-- images
    |-- components
    |   |-- AppPreloader.jsx
    |   |-- ButtonLink.jsx
    |   |-- CookieConsent.jsx
    |   |-- Footer.jsx
    |   |-- Header.jsx
    |   |-- HydrateFallback.jsx
    |   |-- JsonLd.jsx
    |   |-- LazyMapFrame.jsx
    |   |-- PageHeader.jsx
    |   |-- QuickActions.jsx
    |   |-- Reveal.jsx
    |   |-- SEO.jsx
    |   |-- SmartImage.jsx
    |   `-- ThemeTokens.jsx
    |-- data
    |   |-- branches.json
    |   |-- doctors.json
    |   |-- gallery.json
    |   |-- home.json
    |   |-- navigation.json
    |   |-- README.md
    |   |-- services.json
    |   |-- site.json
    |   |-- testimonials.json
    |   `-- theme.json
    |-- i18n
    |   `-- strings.js
    |-- lib
    |   |-- coreData.js
    |   |-- data.js
    |   |-- doctorsData.js
    |   |-- galleryData.js
    |   |-- homeData.js
    |   |-- icons.js
    |   |-- motion.js
    |   |-- schemas.js
    |   |-- servicesData.js
    |   |-- submitAppointment.js
    |   `-- testimonialsData.js
    |-- pages
    |   |-- AboutPage.jsx
    |   |-- AppointmentPage.jsx
    |   |-- BranchesPage.jsx
    |   |-- ContactPage.jsx
    |   |-- DoctorsPage.jsx
    |   |-- GalleryPage.jsx
    |   |-- HomePage.jsx
    |   |-- NotFoundPage.jsx
    |   |-- ServiceDetailPage.jsx
    |   `-- ServicesPage.jsx
    |-- sections
    |   |-- AppointmentBand.jsx      (home)
    |   |-- BranchCards.jsx          (branches page)
    |   |-- BranchLocator.jsx        (home)
    |   |-- CTASection.jsx
    |   |-- DoctorGrid.jsx           (doctors page)
    |   |-- FAQ.jsx
    |   |-- Gallery.jsx
    |   |-- Hero.jsx                 (home)
    |   |-- PageIntroGrid.jsx
    |   |-- PatientStories.jsx       (home)
    |   |-- QuickTreatments.jsx      (home)
    |   |-- ServiceGrid.jsx          (services page)
    |   |-- SignatureServices.jsx    (home)
    |   |-- SpecialistsRail.jsx      (home)
    |   |-- TrustStrip.jsx           (home)
    |   `-- WhyChooseUs.jsx          (home)
    |-- styles
    |   |-- global.css
    |   |-- landing.css
    |   `-- footer.css
    `-- types
        `-- types.js
```

## Architecture Rules

- Pages live in `src/pages` and are loaded through `src/router.jsx` using lazy route modules.
- Reusable page sections live in `src/sections`.
- Shared UI primitives and layout components live in `src/components`.
- Editable content belongs in `src/data` JSON files whenever possible.
- Data access and validation helpers belong in `src/lib`.
- Global styling lives in `src/styles/global.css`; keep changes scoped and avoid unrelated rewrites.
- The landing page owns its own stylesheet at `src/styles/landing.css` under the `.lp-` namespace; the site footer owns `src/styles/footer.css` under the `.ft-` namespace. Both are imported from `src/main.jsx` after `global.css`. Do not restyle landing/footer components from `global.css`.
- `src/lib/contact.js` holds the shared phone/WhatsApp/map link helpers. Use it instead of re-declaring `cleanTel`, `getPrimaryPhone`, `buildWhatsApp` or `buildMapLink` in a component.
- Public media should live under `public/assets/media` and be referenced with `/assets/media/...` paths.
- Prefer existing helpers such as `SEO`, `JsonLd`, `ButtonLink`, `SmartImage`, `Reveal`, and `LazyMapFrame` before creating new primitives.
- Remove dead components, imports, CSS selectors, and unused assets when a section is removed. This site must stay clean and deployment-ready.

## Landing Page Structure

The home page (`src/pages/HomePage.jsx`) renders, in order:

1. `Hero` - rotating background, headline, quick actions, hero proof row and a 30-second booking card that deep-links into `/appointment?branch=&service=&name=`.
2. `TrustStrip` - four credential tiles that overlap the hero.
3. `QuickTreatments` - "what brings you here today" treatment picker.
4. `SignatureServices` - one featured treatment panel plus a three-up service grid.
5. `WhyChooseUs` - dark trust-pillar band.
6. `SpecialistsRail` - four doctor cards.
7. `BranchLocator` - branch switcher with address, phone groups, actions and map.
8. `PatientStories` - aggregated public-review themes (not verbatim patient quotes).
9. `AppointmentBand` - closing conversion band.

`AppointmentPage` reads `branch`, `service` and `name` from the query string so the hero card can prefill the full form.

## Current Routes

```text
/
/about
/services
/services/:slug
/doctors
/branches
/gallery
/appointment
/contact
/*
```

The navigation currently uses `Our Hospitals` in the header with a dropdown that links branch choices into the existing `/branches?branch=<slug>` experience. Separate branch detail pages are planned later, but should not be created until requested.

## UI/UX Standards

- Mobile first: design and test from small screens upward.
- Keep navigation short, obvious, and thumb-friendly.
- Primary actions should be visible and direct: Book Appointment, Call, WhatsApp, Directions.
- Use large tap targets, readable type, strong contrast, and enough spacing for older patients.
- Keep sections purposeful. If a section does not help a patient decide, contact, book, or understand care, simplify or remove it.
- Avoid visual clutter, nested cards, decorative overload, and heavy animations.
- Use real hospital, doctor, branch, and treatment imagery where possible. Avoid generic stock-like visuals when real assets exist.
- Make branch selection easy on mobile; users should quickly choose Visnagar, Ahmedabad, or Bharuch.
- Use icons from Lucide React for actions and navigation cues.
- Preserve accessibility: semantic landmarks, labels, focus states, keyboard access, reduced-motion support, and alt text.
- Ensure every UI works at small mobile widths, tablet widths, laptop widths, and large desktop widths.

## Visual Direction

- The site should feel premium, clinical, clean, and trustworthy.
- Prefer calm medical colors from the existing theme over random new palettes.
- Keep typography readable and polished. Avoid text that is too small, too dense, or squeezed into cards.
- Use motion sparingly for reveal and orientation, not as decoration.
- Keep mobile pages direct and vertically efficient.
- Avoid unnecessary hero complexity. The homepage should get users to care options and contact routes quickly.

## Content And Data Rules

- `src/data/site.json`: brand, logo, global CTAs, defaults, footer, business hours.
- `src/data/navigation.json`: header and footer navigation.
- `src/data/home.json`: homepage hero, stats, timeline, mission/vision, and CTA content.
- `src/data/services.json`: service cards, service details, and FAQs.
- `src/data/doctors.json`: doctor profiles and branch associations.
- `src/data/branches.json`: branch names, slugs, addresses, phone groups, email, maps, WhatsApp numbers.
- `src/data/testimonials.json`: patient quotes.
- `src/data/gallery.json`: gallery categories and media.
- Do not hard-code business content into components when it belongs in JSON.
- Keep branch slugs stable because URLs, query links, and future branch pages depend on them.

## SEO, Trust, And Medical Site Requirements

- Every route should use `SEO` metadata.
- Use JSON-LD helpers where relevant: medical clinic, branch, service, breadcrumb, and FAQ structured data.
- Keep copy medically responsible. Do not make unrealistic guarantees or exaggerated health claims.
- Make phone numbers, WhatsApp links, addresses, maps, and appointment CTAs easy to find.
- Keep `public/robots.txt` and `public/sitemap.xml` aligned with production routes when routes change.
- Verify branch contact details, business hours, maps, and doctor bios before launch.

## Performance Rules

- Keep route-level lazy loading through `src/router.jsx`.
- Use `SmartImage` and public optimized images when possible.
- Use `LazyMapFrame` for embedded maps.
- Avoid unnecessary large libraries.
- Avoid adding complex client-side state when simple JSON-driven rendering is enough.
- After major UI changes, run a production build and check bundle output.

## Quality Checklist Before Handoff

Run:

```bash
npm run lint
npm run build
```

Manual checks:

- Homepage looks clean and direct on mobile.
- Header menu works on desktop and mobile.
- `Our Hospitals` dropdown works and branch choices open the expected branch state.
- Quick actions do not cover important content on mobile.
- Appointment form validates properly.
- Phone, WhatsApp, maps, and email links work.
- All pages fit mobile width without horizontal scrolling.
- Reduced-motion mode does not depend on animation to understand content.
- Lighthouse mobile should be checked for Performance, Accessibility, Best Practices, and SEO before final deployment.

## Known Launch Notes

- Ahmedabad OPD mobile number must be verified before launch.
- Map coordinates are approximate and should be verified.
- Business hours are placeholders and should be confirmed by the hospital team.
- Doctor bios should be replaced with approved final copy.
- Future work may include separate pages for each hospital branch, but for now the navbar links into `/branches?branch=<slug>`.

## Coding Style

- Keep changes minimal, focused, and consistent with existing patterns.
- Do not introduce new abstractions unless they remove real duplication or complexity.
- Prefer clear component names and readable JSX.
- Avoid one-letter variables.
- Avoid comments unless the code would otherwise be hard to understand.
- Use ASCII text unless the file already requires non-ASCII.
- Do not commit changes unless explicitly requested.
